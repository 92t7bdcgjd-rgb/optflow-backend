"""
OPTFLOW Backend — Flask API for options day trading
Connects Yahoo Finance (yfinance) + Robinhood (robin_stocks)

Run:
    pip install flask flask-cors yfinance robin_stocks ta pandas numpy
    python app.py
"""

from flask import Flask, jsonify
from flask_cors import CORS
from routes.auth import auth_bp
from routes.market import market_bp
from routes.options import options_bp
from routes.orders import orders_bp
from routes.strategies import strategies_bp

app = Flask(__name__)
CORS(app, origins=["http://localhost:3000", "https://claude.ai"])  # allow your frontend

# ── Register route blueprints ─────────────────────────────────────────────────
app.register_blueprint(auth_bp,       url_prefix="/api/auth")
app.register_blueprint(market_bp,     url_prefix="/api/market")
app.register_blueprint(options_bp,    url_prefix="/api/options")
app.register_blueprint(orders_bp,     url_prefix="/api/orders")
app.register_blueprint(strategies_bp, url_prefix="/api/strategies")

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "version": "1.0.0"})

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    print("🚀 OPTFLOW backend running on http://localhost:8000")
    app.run(host="0.0.0.0", port=8000, debug=True)
