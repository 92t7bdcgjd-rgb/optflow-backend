"""
routes/orders.py — Robinhood options order management via robin_stocks
"""

from flask import Blueprint, request, jsonify
import robin_stocks.robinhood as r
from datetime import datetime

orders_bp = Blueprint("orders", __name__)

# Local order log (supplement Robinhood's own history)
_order_log = []


@orders_bp.route("/place", methods=["POST"])
def place_order():
    """
    POST /api/orders/place
    Body:
    {
        "ticker":      "AAPL",
        "action":      "BUY_CALL" | "BUY_PUT" | "SELL_CALL" | "SELL_PUT",
        "strike":      195.0,
        "expiry":      "2025-07-18",
        "contracts":   1,
        "limitPrice":  2.50,       // per-contract premium (limit order)
        "orderEffect": "open"      // "open" to buy, "close" to sell existing
    }

    Places a limit order on Robinhood. Options orders are always limit orders
    (market orders on options are generally inadvisable due to wide spreads).
    """
    data = request.json or {}
    ticker      = data.get("ticker", "").upper().strip()
    action      = data.get("action", "").upper()
    strike      = float(data.get("strike", 0))
    expiry      = data.get("expiry", "")
    contracts   = int(data.get("contracts", 1))
    limit_price = float(data.get("limitPrice", 0))
    order_effect= data.get("orderEffect", "open")

    if not all([ticker, action, strike, expiry, limit_price]):
        return jsonify({"error": "Missing required fields"}), 400

    # Parse action into robin_stocks parameters
    if action in ("BUY_CALL", "BUY_PUT"):
        direction   = "debit"
        position_effect = order_effect      # "open"
        side        = "buy"
    elif action in ("SELL_CALL", "SELL_PUT"):
        direction   = "credit"
        position_effect = order_effect      # "close"
        side        = "sell"
    else:
        return jsonify({"error": f"Unknown action: {action}"}), 400

    option_type = "call" if "CALL" in action else "put"

    try:
        # Find the specific contract
        contracts_list = r.options.find_options_by_expiration_and_strike(
            ticker,
            expirationDate=expiry,
            strikePrice=str(strike),
            optionType=option_type,
        )
        if not contracts_list:
            return jsonify({"error": f"No contract found: {ticker} {expiry} ${strike} {option_type}"}), 404

        # Place the order
        if side == "buy":
            order_result = r.orders.order_buy_option_limit(
                positionEffect=position_effect,
                creditOrDebit=direction,
                price=limit_price,
                symbol=ticker,
                quantity=contracts,
                expirationDate=expiry,
                strike=strike,
                optionType=option_type,
            )
        else:
            order_result = r.orders.order_sell_option_limit(
                positionEffect=position_effect,
                creditOrDebit=direction,
                price=limit_price,
                symbol=ticker,
                quantity=contracts,
                expirationDate=expiry,
                strike=strike,
                optionType=option_type,
            )

        entry = {
            "id":           order_result.get("id"),
            "ticker":       ticker,
            "action":       action,
            "optionType":   option_type,
            "strike":       strike,
            "expiry":       expiry,
            "contracts":    contracts,
            "limitPrice":   limit_price,
            "status":       order_result.get("state", "queued"),
            "rhOrderId":    order_result.get("id"),
            "placedAt":     datetime.utcnow().isoformat() + "Z",
            "raw":          order_result,
        }
        _order_log.insert(0, entry)

        return jsonify({"success": True, "order": entry})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@orders_bp.route("/cancel/<order_id>", methods=["POST"])
def cancel_order(order_id):
    """
    POST /api/orders/cancel/<order_id>
    Cancels an open Robinhood options order.
    """
    try:
        result = r.orders.cancel_option_order(order_id)
        # Update local log
        for o in _order_log:
            if o.get("rhOrderId") == order_id:
                o["status"] = "cancelled"
        return jsonify({"success": True, "result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@orders_bp.route("/all", methods=["GET"])
def get_all_orders():
    """
    GET /api/orders/all
    Returns all options orders from Robinhood (open + historical).
    """
    try:
        rh_orders = r.orders.get_all_option_orders() or []
        formatted = []
        for o in rh_orders:
            legs = o.get("legs", [{}])
            leg  = legs[0] if legs else {}
            formatted.append({
                "id":          o.get("id"),
                "ticker":      o.get("chain_symbol"),
                "state":       o.get("state"),
                "direction":   o.get("direction"),
                "price":       o.get("price"),
                "quantity":    o.get("quantity"),
                "side":        leg.get("side"),
                "optionType":  leg.get("option_type"),
                "strike":      leg.get("strike_price"),
                "expiry":      leg.get("expiration_date"),
                "createdAt":   o.get("created_at"),
                "updatedAt":   o.get("updated_at"),
                "cancelUrl":   o.get("cancel"),
            })
        return jsonify({"orders": formatted, "count": len(formatted)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@orders_bp.route("/open", methods=["GET"])
def get_open_orders():
    """GET /api/orders/open — Open (pending) orders only."""
    try:
        all_orders = r.orders.get_all_option_orders() or []
        open_orders = [o for o in all_orders if o.get("state") in ("queued", "unconfirmed", "confirmed", "partially_filled")]
        return jsonify({"orders": open_orders, "count": len(open_orders)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@orders_bp.route("/positions", methods=["GET"])
def get_positions():
    """
    GET /api/orders/positions
    Returns current open options positions with P&L.
    """
    try:
        positions = r.account.get_open_option_positions() or []
        formatted = []
        for pos in positions:
            avg_price = float(pos.get("average_price") or 0)
            quantity  = float(pos.get("quantity") or 0)
            formatted.append({
                "id":           pos.get("option_id"),
                "ticker":       pos.get("chain_symbol"),
                "type":         pos.get("type"),
                "quantity":     quantity,
                "avgPrice":     avg_price,
                "costBasis":    round(avg_price * quantity * 100, 2),
                "tradeSide":    pos.get("trade_value_multiplier"),
                "createdAt":    pos.get("created_at"),
                "updatedAt":    pos.get("updated_at"),
            })
        return jsonify({"positions": formatted, "count": len(formatted)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@orders_bp.route("/local-log", methods=["GET"])
def get_local_log():
    """GET /api/orders/local-log — OPTFLOW's own order log."""
    return jsonify({"orders": _order_log, "count": len(_order_log)})
