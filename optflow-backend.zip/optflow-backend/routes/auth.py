"""
routes/auth.py — Robinhood authentication via robin_stocks
"""

from flask import Blueprint, request, jsonify, session
import robin_stocks.robinhood as r

auth_bp = Blueprint("auth", __name__)

# In-memory session flag (use Redis/DB in production)
_logged_in = False
_username = None


@auth_bp.route("/login", methods=["POST"])
def login():
    """
    POST /api/auth/login
    Body: { "username": "...", "password": "..." }

    Robinhood requires 2FA by default. If your account has SMS 2FA enabled,
    robin_stocks will prompt for the code interactively — or you can disable
    2FA in Robinhood settings and pass store_session=True to cache the token.
    """
    global _logged_in, _username
    data = request.json or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    mfa_code = data.get("mfa_code", "").strip() or None  # optional

    if not username or not password:
        return jsonify({"error": "Username and password required"}), 400

    try:
        login_result = r.login(
            username=username,
            password=password,
            mfa_code=mfa_code,
            store_session=True,   # caches token in ~/.tokens/
            by_sms=True,          # use SMS 2FA if enabled
        )
        if login_result:
            _logged_in = True
            _username = username
            return jsonify({"success": True, "username": username})
        else:
            return jsonify({"error": "Login failed — check credentials"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@auth_bp.route("/logout", methods=["POST"])
def logout():
    global _logged_in, _username
    try:
        r.logout()
        _logged_in = False
        _username = None
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@auth_bp.route("/status", methods=["GET"])
def status():
    return jsonify({"connected": _logged_in, "username": _username})
