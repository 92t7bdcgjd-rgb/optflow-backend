"""
routes/options.py — Options chain data from Yahoo Finance + Robinhood
"""

from flask import Blueprint, request, jsonify
import yfinance as yf
import robin_stocks.robinhood as r
import math

options_bp = Blueprint("options", __name__)


def _safe(val):
    try:
        v = float(val)
        return None if (v != v) else round(v, 4)
    except Exception:
        return None


def _black_scholes_delta(S, K, T, r_rate, sigma, option_type="call"):
    """Compute Black-Scholes delta when not provided by broker."""
    if T <= 0 or sigma <= 0:
        return None
    try:
        d1 = (math.log(S / K) + (r_rate + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))
        from scipy.stats import norm
        if option_type == "call":
            return round(norm.cdf(d1), 4)
        else:
            return round(norm.cdf(d1) - 1, 4)
    except Exception:
        return None


@options_bp.route("/expirations/<ticker>", methods=["GET"])
def get_expirations(ticker):
    """
    GET /api/options/expirations/AAPL
    Returns list of available expiry dates.
    """
    ticker = ticker.upper().strip()
    try:
        t = yf.Ticker(ticker)
        return jsonify({"symbol": ticker, "expirations": list(t.options)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@options_bp.route("/chain/<ticker>", methods=["GET"])
def get_chain(ticker):
    """
    GET /api/options/chain/AAPL?expiry=2025-07-18&type=call
    Returns full options chain for a given expiry.
    """
    ticker = ticker.upper().strip()
    expiry = request.args.get("expiry")
    opt_type = request.args.get("type", "both").lower()  # call, put, both

    try:
        t = yf.Ticker(ticker)
        current_price = t.info.get("currentPrice") or t.info.get("regularMarketPrice", 0)
        expirations = list(t.options)

        if not expiry:
            expiry = expirations[0] if expirations else None
        if not expiry:
            return jsonify({"error": "No expiry dates available"}), 404

        chain = t.option_chain(expiry)

        def format_contracts(df, side):
            rows = []
            for _, row in df.iterrows():
                rows.append({
                    "contractSymbol":    row.get("contractSymbol"),
                    "type":              side,
                    "strike":            _safe(row.get("strike")),
                    "lastPrice":         _safe(row.get("lastPrice")),
                    "bid":               _safe(row.get("bid")),
                    "ask":               _safe(row.get("ask")),
                    "midpoint":          round((_safe(row.get("bid")) or 0 + _safe(row.get("ask")) or 0) / 2, 4),
                    "change":            _safe(row.get("change")),
                    "pctChange":         _safe(row.get("percentChange")),
                    "volume":            int(row.get("volume") or 0),
                    "openInterest":      int(row.get("openInterest") or 0),
                    "impliedVolatility": _safe(row.get("impliedVolatility")),
                    "inTheMoney":        bool(row.get("inTheMoney", False)),
                    "expiry":            expiry,
                })
            return rows

        result = {"symbol": ticker, "expiry": expiry, "currentPrice": current_price}

        if opt_type in ("call", "both"):
            result["calls"] = format_contracts(chain.calls, "call")
        if opt_type in ("put", "both"):
            result["puts"] = format_contracts(chain.puts, "put")

        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@options_bp.route("/near-money/<ticker>", methods=["GET"])
def get_near_money(ticker):
    """
    GET /api/options/near-money/AAPL?expiry=2025-07-18&width=5
    Returns ATM ± width strikes (useful for strategy screens).
    """
    ticker = ticker.upper().strip()
    expiry = request.args.get("expiry")
    width  = int(request.args.get("width", 5))

    try:
        t = yf.Ticker(ticker)
        info = t.info
        current_price = float(info.get("currentPrice") or info.get("regularMarketPrice", 0))
        expirations   = list(t.options)
        if not expiry:
            expiry = expirations[0]

        chain = t.option_chain(expiry)

        def near(df, side):
            df = df.copy()
            df["dist"] = abs(df["strike"] - current_price)
            df = df.sort_values("dist").head(width * 2)
            return [
                {
                    "type":              side,
                    "strike":            _safe(r["strike"]),
                    "bid":               _safe(r["bid"]),
                    "ask":               _safe(r["ask"]),
                    "iv":                _safe(r["impliedVolatility"]),
                    "oi":                int(r["openInterest"] or 0),
                    "volume":            int(r["volume"] or 0),
                    "inTheMoney":        bool(r["inTheMoney"]),
                    "expiry":            expiry,
                    "contractSymbol":    r["contractSymbol"],
                }
                for _, r in df.iterrows()
            ]

        return jsonify({
            "symbol":       ticker,
            "currentPrice": current_price,
            "expiry":       expiry,
            "calls":        near(chain.calls, "call"),
            "puts":         near(chain.puts, "put"),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@options_bp.route("/iv-rank/<ticker>", methods=["GET"])
def get_iv_rank(ticker):
    """
    GET /api/options/iv-rank/AAPL
    Computes IV Rank and IV Percentile over the past year.
    Useful for IV crush / earnings strategy signals.
    """
    ticker = ticker.upper().strip()
    try:
        import yfinance as yf
        t    = yf.Ticker(ticker)
        hist = t.history(period="1y", interval="1d")

        # Approximate HV as rolling 30-day annualised std
        hist["log_ret"] = (hist["Close"] / hist["Close"].shift(1)).apply(lambda x: math.log(x) if x > 0 else 0)
        hist["hv30"] = hist["log_ret"].rolling(30).std() * math.sqrt(252)

        hv_series = hist["hv30"].dropna()
        current_hv = float(hv_series.iloc[-1])
        hv_min     = float(hv_series.min())
        hv_max     = float(hv_series.max())

        iv_rank = round((current_hv - hv_min) / (hv_max - hv_min) * 100, 1) if hv_max != hv_min else 50.0
        iv_pct  = round((hv_series <= current_hv).sum() / len(hv_series) * 100, 1)

        return jsonify({
            "symbol":         ticker,
            "currentHV30":    round(current_hv * 100, 2),
            "hvMin":          round(hv_min * 100, 2),
            "hvMax":          round(hv_max * 100, 2),
            "ivRank":         iv_rank,
            "ivPercentile":   iv_pct,
            "interpretation": (
                "High IV — good for premium selling / IV crush plays" if iv_rank > 50
                else "Low IV — good for buying options / breakout plays"
            )
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
