"""
routes/market.py — Real-time market data from Yahoo Finance via yfinance
"""

from flask import Blueprint, request, jsonify
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

market_bp = Blueprint("market", __name__)


def _safe_float(val):
    try:
        f = float(val)
        return None if (f != f) else round(f, 4)  # NaN check
    except Exception:
        return None


@market_bp.route("/quote/<ticker>", methods=["GET"])
def get_quote(ticker):
    """
    GET /api/market/quote/AAPL
    Returns current price, change, IV, beta, volume, etc.
    """
    ticker = ticker.upper().strip()
    try:
        t = yf.Ticker(ticker)
        info = t.info

        price      = _safe_float(info.get("currentPrice") or info.get("regularMarketPrice"))
        prev_close = _safe_float(info.get("previousClose") or info.get("regularMarketPreviousClose"))
        change     = round(price - prev_close, 4) if price and prev_close else None
        change_pct = round((change / prev_close) * 100, 4) if change and prev_close else None

        return jsonify({
            "symbol":            ticker,
            "name":              info.get("longName") or info.get("shortName", ticker),
            "price":             price,
            "previousClose":     prev_close,
            "change":            change,
            "changePct":         change_pct,
            "open":              _safe_float(info.get("open")),
            "dayHigh":           _safe_float(info.get("dayHigh")),
            "dayLow":            _safe_float(info.get("dayLow")),
            "volume":            info.get("volume"),
            "avgVolume":         info.get("averageVolume"),
            "marketCap":         info.get("marketCap"),
            "week52High":        _safe_float(info.get("fiftyTwoWeekHigh")),
            "week52Low":         _safe_float(info.get("fiftyTwoWeekLow")),
            "impliedVolatility": None,  # pulled per-expiry in /options endpoint
            "beta":              _safe_float(info.get("beta")),
            "pe":                _safe_float(info.get("trailingPE")),
            "eps":               _safe_float(info.get("trailingEps")),
            "sector":            info.get("sector"),
            "industry":          info.get("industry"),
            "earningsDate":      str(info.get("earningsTimestamp", "")),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@market_bp.route("/history/<ticker>", methods=["GET"])
def get_history(ticker):
    """
    GET /api/market/history/AAPL?period=1d&interval=5m
    period options: 1d, 5d, 1mo, 3mo, 6mo, 1y
    interval options: 1m, 5m, 15m, 30m, 1h, 1d
    """
    ticker   = ticker.upper().strip()
    period   = request.args.get("period", "1d")
    interval = request.args.get("interval", "5m")

    try:
        t    = yf.Ticker(ticker)
        hist = t.history(period=period, interval=interval)
        hist.index = hist.index.astype(str)

        candles = [
            {
                "time":   str(ts),
                "open":   round(float(row["Open"]),  4),
                "high":   round(float(row["High"]),  4),
                "low":    round(float(row["Low"]),   4),
                "close":  round(float(row["Close"]), 4),
                "volume": int(row["Volume"]),
            }
            for ts, row in hist.iterrows()
        ]
        return jsonify({"symbol": ticker, "period": period, "interval": interval, "candles": candles})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@market_bp.route("/technicals/<ticker>", methods=["GET"])
def get_technicals(ticker):
    """
    GET /api/market/technicals/AAPL
    Computes RSI, MACD, Bollinger Bands, EMA, SMA from yfinance + ta library
    """
    ticker = ticker.upper().strip()
    try:
        import ta
        t    = yf.Ticker(ticker)
        hist = t.history(period="3mo", interval="1d")

        close  = hist["Close"]
        high   = hist["High"]
        low    = hist["Low"]
        volume = hist["Volume"]

        rsi   = ta.momentum.RSIIndicator(close, window=14).rsi().iloc[-1]
        macd  = ta.trend.MACD(close)
        bb    = ta.volatility.BollingerBands(close, window=20, window_dev=2)
        ema20 = ta.trend.EMAIndicator(close, window=20).ema_indicator().iloc[-1]
        sma50 = ta.trend.SMAIndicator(close, window=50).sma_indicator().iloc[-1]
        sma200= ta.trend.SMAIndicator(close, window=200).sma_indicator().iloc[-1]
        atr   = ta.volatility.AverageTrueRange(high, low, close, window=14).average_true_range().iloc[-1]

        current_price = float(close.iloc[-1])

        return jsonify({
            "symbol":        ticker,
            "currentPrice":  round(current_price, 4),
            "rsi":           round(float(rsi), 2),
            "macd": {
                "macd":      round(float(macd.macd().iloc[-1]), 4),
                "signal":    round(float(macd.macd_signal().iloc[-1]), 4),
                "histogram": round(float(macd.macd_diff().iloc[-1]), 4),
            },
            "bollingerBands": {
                "upper":  round(float(bb.bollinger_hband().iloc[-1]), 4),
                "middle": round(float(bb.bollinger_mavg().iloc[-1]), 4),
                "lower":  round(float(bb.bollinger_lband().iloc[-1]), 4),
                "width":  round(float(bb.bollinger_wband().iloc[-1]), 4),
            },
            "ema20":  round(float(ema20), 4),
            "sma50":  round(float(sma50), 4),
            "sma200": round(float(sma200), 4),
            "atr":    round(float(atr), 4),
            # Derived signals
            "signals": {
                "rsi_oversold":    float(rsi) < 30,
                "rsi_overbought":  float(rsi) > 70,
                "above_ema20":     current_price > float(ema20),
                "above_sma50":     current_price > float(sma50),
                "golden_cross":    float(ema20) > float(sma50),
                "macd_bullish":    float(macd.macd_diff().iloc[-1]) > 0,
                "bb_squeeze":      float(bb.bollinger_wband().iloc[-1]) < 0.1,
                "near_bb_upper":   current_price > float(bb.bollinger_hband().iloc[-1]) * 0.99,
                "near_bb_lower":   current_price < float(bb.bollinger_lband().iloc[-1]) * 1.01,
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
