"""
routes/strategies.py — Options strategy signal engine
Combines Yahoo Finance data + technical analysis to generate trade signals.

Strategies:
  1. Momentum Breakout   — volume surge + price breakout above resistance
  2. IV Crush / Earnings — high IV rank + near earnings = sell premium or buy directional
  3. Trend + Technicals  — MACD cross + RSI + moving average alignment
"""

from flask import Blueprint, request, jsonify
import yfinance as yf
import pandas as pd
import numpy as np
import math
from datetime import datetime, timedelta

strategies_bp = Blueprint("strategies", __name__)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _get_technicals(ticker):
    """Pull 3-month daily history and compute indicators."""
    import ta
    t    = yf.Ticker(ticker)
    hist = t.history(period="3mo", interval="1d")
    if hist.empty:
        return None, None

    close  = hist["Close"]
    high   = hist["High"]
    low    = hist["Low"]
    volume = hist["Volume"]

    rsi   = ta.momentum.RSIIndicator(close, window=14).rsi()
    macd_ind = ta.trend.MACD(close)
    bb    = ta.volatility.BollingerBands(close, window=20, window_dev=2)
    ema20 = ta.trend.EMAIndicator(close, window=20).ema_indicator()
    sma50 = ta.trend.SMAIndicator(close, window=50).sma_indicator()
    atr   = ta.volatility.AverageTrueRange(high, low, close, window=14).average_true_range()

    signals = {
        "price":           float(close.iloc[-1]),
        "rsi":             float(rsi.iloc[-1]),
        "macd":            float(macd_ind.macd().iloc[-1]),
        "macd_signal":     float(macd_ind.macd_signal().iloc[-1]),
        "macd_hist":       float(macd_ind.macd_diff().iloc[-1]),
        "macd_hist_prev":  float(macd_ind.macd_diff().iloc[-2]),
        "bb_upper":        float(bb.bollinger_hband().iloc[-1]),
        "bb_lower":        float(bb.bollinger_lband().iloc[-1]),
        "bb_width":        float(bb.bollinger_wband().iloc[-1]),
        "ema20":           float(ema20.iloc[-1]),
        "sma50":           float(sma50.iloc[-1]),
        "atr":             float(atr.iloc[-1]),
        "volume":          float(volume.iloc[-1]),
        "avg_volume_20":   float(volume.rolling(20).mean().iloc[-1]),
        "volume_surge":    float(volume.iloc[-1]) / float(volume.rolling(20).mean().iloc[-1]),
        "price_5d_ago":    float(close.iloc[-5]) if len(close) >= 5 else float(close.iloc[0]),
        "high_20d":        float(high.rolling(20).max().iloc[-1]),
        "low_20d":         float(low.rolling(20).min().iloc[-1]),
    }
    return signals, t.info


def _nearest_expiry(t, weeks_out=1):
    """Get expiry date ~N weeks out."""
    try:
        opts = list(t.options)
        target = datetime.now() + timedelta(weeks=weeks_out)
        closest = min(opts, key=lambda d: abs(datetime.strptime(d, "%Y-%m-%d") - target))
        return closest
    except Exception:
        return None


def _nearest_strike(chain_df, price, option_type="call"):
    """Find ATM strike from chain."""
    try:
        df = chain_df.copy()
        df["dist"] = abs(df["strike"] - price)
        return float(df.sort_values("dist").iloc[0]["strike"])
    except Exception:
        return round(price / 5) * 5


def _contract_premium(chain_df, strike):
    """Get mid-price for a given strike."""
    try:
        row = chain_df[chain_df["strike"] == strike].iloc[0]
        bid = float(row.get("bid") or 0)
        ask = float(row.get("ask") or 0)
        return round((bid + ask) / 2, 2) if ask > 0 else round(float(row.get("lastPrice") or 1.0), 2)
    except Exception:
        return None


# ── Strategy 1: Momentum Breakout ─────────────────────────────────────────────

def _momentum_breakout(ticker, sigs, info, t):
    """
    Signal: Volume surge (>1.5x avg) + price breaking above 20-day high.
    Trade: Buy ATM call (bullish) or put (bearish breakdown).
    """
    results = []
    price        = sigs["price"]
    vol_surge    = sigs["volume_surge"]
    high_20d     = sigs["high_20d"]
    low_20d      = sigs["low_20d"]
    atr          = sigs["atr"]
    price_5d_ago = sigs["price_5d_ago"]
    momentum_5d  = (price - price_5d_ago) / price_5d_ago * 100

    # Bullish breakout
    if vol_surge >= 1.5 and price >= high_20d * 0.99:
        expiry = _nearest_expiry(t, weeks_out=2)
        if expiry:
            chain  = t.option_chain(expiry)
            strike = _nearest_strike(chain.calls, price, "call")
            premium = _contract_premium(chain.calls, strike) or round(price * 0.015, 2)
            confidence = "HIGH" if vol_surge >= 2.0 and momentum_5d > 3 else "MODERATE"
            results.append({
                "strategy":    "Momentum Breakout",
                "action":      "BUY_CALL",
                "strike":      strike,
                "expiry":      expiry,
                "contracts":   1,
                "entryPrice":  premium,
                "targetPrice": round(premium * 2.2, 2),
                "stopLoss":    round(premium * 0.45, 2),
                "confidence":  confidence,
                "riskReward":  "1:2.2",
                "rationale":   f"Volume surge {vol_surge:.1f}x avg with price breaking 20-day high ${high_20d:.2f}. Momentum +{momentum_5d:.1f}% over 5 days.",
                "indicators":  {"volumeSurge": round(vol_surge, 2), "momentum5d": round(momentum_5d, 2), "high20d": round(high_20d, 2)},
            })

    # Bearish breakdown
    if vol_surge >= 1.5 and price <= low_20d * 1.01 and momentum_5d < -2:
        expiry = _nearest_expiry(t, weeks_out=2)
        if expiry:
            chain  = t.option_chain(expiry)
            strike = _nearest_strike(chain.puts, price, "put")
            premium = _contract_premium(chain.puts, strike) or round(price * 0.015, 2)
            results.append({
                "strategy":    "Momentum Breakdown",
                "action":      "BUY_PUT",
                "strike":      strike,
                "expiry":      expiry,
                "contracts":   1,
                "entryPrice":  premium,
                "targetPrice": round(premium * 2.0, 2),
                "stopLoss":    round(premium * 0.45, 2),
                "confidence":  "MODERATE",
                "riskReward":  "1:2.0",
                "rationale":   f"Volume surge {vol_surge:.1f}x avg with price breaking below 20-day low ${low_20d:.2f}.",
                "indicators":  {"volumeSurge": round(vol_surge, 2), "momentum5d": round(momentum_5d, 2), "low20d": round(low_20d, 2)},
            })

    return results


# ── Strategy 2: IV Crush / Earnings ───────────────────────────────────────────

def _iv_crush(ticker, sigs, info, t):
    """
    Signal: High IV rank + earnings within 5 days = sell premium (straddle/iron condor candidate).
    High IV + no earnings = buy directional if price is moving.
    """
    results = []
    price = sigs["price"]

    # Estimate IV rank from BB width as proxy (real IV rank requires options history)
    bb_width   = sigs["bb_width"]
    iv_elevated = bb_width > 0.08  # >8% BB width = elevated vol
    iv_extreme  = bb_width > 0.14

    # Check earnings proximity
    earnings_ts = info.get("earningsTimestamp")
    days_to_earnings = None
    if earnings_ts:
        try:
            earnings_dt = datetime.fromtimestamp(earnings_ts)
            days_to_earnings = (earnings_dt - datetime.now()).days
        except Exception:
            pass

    near_earnings = days_to_earnings is not None and 0 <= days_to_earnings <= 7

    if near_earnings and iv_elevated:
        # Earnings play: buy ATM straddle (both call + put)
        expiry = _nearest_expiry(t, weeks_out=1)
        if expiry:
            chain  = t.option_chain(expiry)
            strike = _nearest_strike(chain.calls, price)
            call_prem = _contract_premium(chain.calls, strike) or round(price * 0.02, 2)
            put_prem  = _contract_premium(chain.puts,  strike) or round(price * 0.02, 2)
            total_cost = round(call_prem + put_prem, 2)
            results.append({
                "strategy":    "Earnings Straddle",
                "action":      "BUY_CALL",
                "strike":      strike,
                "expiry":      expiry,
                "contracts":   1,
                "entryPrice":  call_prem,
                "targetPrice": round(call_prem * 2.5, 2),
                "stopLoss":    round(call_prem * 0.4, 2),
                "confidence":  "HIGH" if iv_extreme else "MODERATE",
                "riskReward":  "1:2.5",
                "rationale":   f"Earnings in {days_to_earnings} day(s). IV elevated (BB width {bb_width:.2%}). Buy straddle: ${total_cost:.2f} total cost per contract pair.",
                "indicators":  {"daysToEarnings": days_to_earnings, "bbWidth": round(bb_width, 4), "callPrem": call_prem, "putPrem": put_prem},
            })

    elif iv_elevated and not near_earnings:
        # IV crush play: sell elevated premium after no-event vol spike
        expiry = _nearest_expiry(t, weeks_out=2)
        if expiry:
            # OTM call (credit spread candidate)
            chain      = t.option_chain(expiry)
            otm_strike = round((price * 1.05) / 5) * 5
            premium    = _contract_premium(chain.calls, otm_strike) or round(price * 0.008, 2)
            if premium and premium > 0.3:
                results.append({
                    "strategy":    "IV Crush — Sell OTM Call",
                    "action":      "SELL_CALL",
                    "strike":      otm_strike,
                    "expiry":      expiry,
                    "contracts":   1,
                    "entryPrice":  premium,
                    "targetPrice": round(premium * 0.25, 2),
                    "stopLoss":    round(premium * 2.0, 2),
                    "confidence":  "MODERATE",
                    "riskReward":  "1:0.75",
                    "rationale":   f"IV elevated (BB width {bb_width:.2%}) without catalyst. Sell OTM call to harvest premium decay.",
                    "indicators":  {"bbWidth": round(bb_width, 4), "otmStrike": otm_strike},
                })

    return results


# ── Strategy 3: Trend + Technicals ────────────────────────────────────────────

def _trend_technicals(ticker, sigs, info, t):
    """
    Signal: MACD crossover + RSI not overbought/oversold + above/below key MAs.
    """
    results = []
    price   = sigs["price"]
    rsi     = sigs["rsi"]
    ema20   = sigs["ema20"]
    sma50   = sigs["sma50"]
    macd_h  = sigs["macd_hist"]
    macd_hp = sigs["macd_hist_prev"]
    atr     = sigs["atr"]

    macd_crossed_up   = macd_h > 0 and macd_hp <= 0
    macd_crossed_down = macd_h < 0 and macd_hp >= 0
    above_ema20 = price > ema20
    above_sma50 = price > sma50
    rsi_ok_bull = 40 < rsi < 70
    rsi_ok_bear = 30 < rsi < 60

    # Bullish trend signal
    if macd_crossed_up and above_ema20 and above_sma50 and rsi_ok_bull:
        expiry = _nearest_expiry(t, weeks_out=3)
        if expiry:
            chain  = t.option_chain(expiry)
            # Slightly OTM call (delta ~0.40)
            strike = round((price * 1.02) / 5) * 5
            premium = _contract_premium(chain.calls, strike) or round(price * 0.012, 2)
            results.append({
                "strategy":    "Trend Follow — Bullish",
                "action":      "BUY_CALL",
                "strike":      strike,
                "expiry":      expiry,
                "contracts":   1,
                "entryPrice":  premium,
                "targetPrice": round(premium * 2.5, 2),
                "stopLoss":    round(premium * 0.4, 2),
                "confidence":  "HIGH",
                "riskReward":  "1:2.5",
                "rationale":   f"MACD bullish crossover. Price above EMA20 (${ema20:.2f}) and SMA50 (${sma50:.2f}). RSI {rsi:.0f} — room to run.",
                "indicators":  {"rsi": round(rsi, 1), "ema20": round(ema20, 2), "sma50": round(sma50, 2), "macdHist": round(macd_h, 4)},
            })

    # Bearish trend signal
    if macd_crossed_down and not above_ema20 and not above_sma50 and rsi_ok_bear:
        expiry = _nearest_expiry(t, weeks_out=3)
        if expiry:
            chain  = t.option_chain(expiry)
            strike = round((price * 0.98) / 5) * 5
            premium = _contract_premium(chain.puts, strike) or round(price * 0.012, 2)
            results.append({
                "strategy":    "Trend Follow — Bearish",
                "action":      "BUY_PUT",
                "strike":      strike,
                "expiry":      expiry,
                "contracts":   1,
                "entryPrice":  premium,
                "targetPrice": round(premium * 2.5, 2),
                "stopLoss":    round(premium * 0.4, 2),
                "confidence":  "HIGH",
                "riskReward":  "1:2.5",
                "rationale":   f"MACD bearish crossover. Price below EMA20 (${ema20:.2f}) and SMA50 (${sma50:.2f}). RSI {rsi:.0f}.",
                "indicators":  {"rsi": round(rsi, 1), "ema20": round(ema20, 2), "sma50": round(sma50, 2), "macdHist": round(macd_h, 4)},
            })

    # RSI oversold bounce
    if rsi < 32 and above_sma50:
        expiry = _nearest_expiry(t, weeks_out=2)
        if expiry:
            chain  = t.option_chain(expiry)
            strike = _nearest_strike(chain.calls, price)
            premium = _contract_premium(chain.calls, strike) or round(price * 0.015, 2)
            results.append({
                "strategy":    "RSI Oversold Bounce",
                "action":      "BUY_CALL",
                "strike":      strike,
                "expiry":      expiry,
                "contracts":   1,
                "entryPrice":  premium,
                "targetPrice": round(premium * 2.0, 2),
                "stopLoss":    round(premium * 0.45, 2),
                "confidence":  "MODERATE",
                "riskReward":  "1:2.0",
                "rationale":   f"RSI {rsi:.0f} — oversold while price holds above SMA50. Mean-reversion bounce candidate.",
                "indicators":  {"rsi": round(rsi, 1), "sma50": round(sma50, 2)},
            })

    return results


# ── Main endpoint ──────────────────────────────────────────────────────────────

@strategies_bp.route("/analyze/<ticker>", methods=["GET"])
def analyze(ticker):
    """
    GET /api/strategies/analyze/AAPL?strategies=momentum,iv_crush,trend
    Returns a list of options trade signals with strikes, expiries, and rationale.
    """
    ticker     = ticker.upper().strip()
    requested  = request.args.get("strategies", "momentum,iv_crush,trend").split(",")

    try:
        t = yf.Ticker(ticker)
        sigs, info = _get_technicals(ticker)
        if sigs is None:
            return jsonify({"error": f"Could not fetch data for {ticker}"}), 404

        all_signals = []

        if "momentum" in requested:
            all_signals.extend(_momentum_breakout(ticker, sigs, info, t))
        if "iv_crush" in requested:
            all_signals.extend(_iv_crush(ticker, sigs, info, t))
        if "trend" in requested:
            all_signals.extend(_trend_technicals(ticker, sigs, info, t))

        # Sort by confidence
        order = {"HIGH": 0, "MODERATE": 1, "LOW": 2}
        all_signals.sort(key=lambda s: order.get(s.get("confidence", "LOW"), 2))

        return jsonify({
            "symbol":      ticker,
            "price":       sigs["price"],
            "analyzedAt":  datetime.utcnow().isoformat() + "Z",
            "signals":     all_signals,
            "technicals":  {
                "rsi":       round(sigs["rsi"], 1),
                "macdHist":  round(sigs["macd_hist"], 4),
                "ema20":     round(sigs["ema20"], 2),
                "sma50":     round(sigs["sma50"], 2),
                "bbWidth":   round(sigs["bb_width"], 4),
                "volSurge":  round(sigs["volume_surge"], 2),
                "atr":       round(sigs["atr"], 2),
            },
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@strategies_bp.route("/scan", methods=["POST"])
def scan_watchlist():
    """
    POST /api/strategies/scan
    Body: { "tickers": ["AAPL", "NVDA", "SPY"], "strategies": ["momentum","trend"] }
    Scans a watchlist and returns all signals ranked by confidence.
    """
    data       = request.json or {}
    tickers    = [t.upper().strip() for t in data.get("tickers", [])]
    strategies = data.get("strategies", ["momentum", "iv_crush", "trend"])

    if not tickers:
        return jsonify({"error": "Provide at least one ticker"}), 400

    results = []
    errors  = []

    for ticker in tickers:
        try:
            t = yf.Ticker(ticker)
            sigs, info = _get_technicals(ticker)
            if sigs is None:
                errors.append({"ticker": ticker, "error": "No data"})
                continue

            signals = []
            if "momentum" in strategies:
                signals.extend(_momentum_breakout(ticker, sigs, info, t))
            if "iv_crush" in strategies:
                signals.extend(_iv_crush(ticker, sigs, info, t))
            if "trend" in strategies:
                signals.extend(_trend_technicals(ticker, sigs, info, t))

            for s in signals:
                s["ticker"] = ticker
                s["price"]  = sigs["price"]
            results.extend(signals)
        except Exception as e:
            errors.append({"ticker": ticker, "error": str(e)})

    order = {"HIGH": 0, "MODERATE": 1, "LOW": 2}
    results.sort(key=lambda s: order.get(s.get("confidence", "LOW"), 2))

    return jsonify({
        "signals":    results,
        "totalCount": len(results),
        "errors":     errors,
        "scannedAt":  datetime.utcnow().isoformat() + "Z",
    })
