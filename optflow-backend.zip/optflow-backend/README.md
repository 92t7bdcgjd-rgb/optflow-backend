# OPTFLOW Backend

Flask API that powers the OPTFLOW options day-trade terminal.  
Connects **Yahoo Finance** (market data + options chains) with **Robinhood** (order execution).

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the server

```bash
python app.py
# → Running on http://localhost:8000
```

### 3. Connect your frontend

In the OPTFLOW React app, change the API base URL from mock to:
```
http://localhost:8000/api
```

---

## Robinhood 2FA Setup

Robinhood requires two-factor authentication. Before using the login endpoint:

1. Log into Robinhood → Account → Security → **Disable SMS 2FA** (use authenticator app or disable entirely for automation)
2. First login will ask for your 2FA code — pass it as `mfa_code` in the login request
3. After first login, `store_session=True` caches your token in `~/.tokens/` — subsequent logins won't need 2FA

---

## API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login to Robinhood |
| POST | `/api/auth/logout` | Logout |
| GET  | `/api/auth/status` | Check connection status |

**Login body:**
```json
{ "username": "you@email.com", "password": "yourpassword", "mfa_code": "123456" }
```

---

### Market Data
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/market/quote/AAPL` | Current price, change, beta, IV |
| GET | `/api/market/history/AAPL?period=1d&interval=5m` | OHLCV candles |
| GET | `/api/market/technicals/AAPL` | RSI, MACD, Bollinger Bands, EMAs |

---

### Options Chain
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/options/expirations/AAPL` | Available expiry dates |
| GET | `/api/options/chain/AAPL?expiry=2025-07-18&type=call` | Full chain |
| GET | `/api/options/near-money/AAPL?expiry=2025-07-18&width=5` | ATM ± N strikes |
| GET | `/api/options/iv-rank/AAPL` | IV rank + IV percentile |

---

### Strategy Engine
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/strategies/analyze/AAPL?strategies=momentum,iv_crush,trend` | Single ticker signals |
| POST | `/api/strategies/scan` | Scan a full watchlist |

**Scan body:**
```json
{
  "tickers": ["AAPL", "NVDA", "SPY", "TSLA"],
  "strategies": ["momentum", "iv_crush", "trend"]
}
```

---

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/orders/place` | Place options limit order |
| POST | `/api/orders/cancel/<order_id>` | Cancel open order |
| GET  | `/api/orders/all` | All orders (open + history) |
| GET  | `/api/orders/open` | Open orders only |
| GET  | `/api/orders/positions` | Current open positions |
| GET  | `/api/orders/local-log` | OPTFLOW's own order log |

**Place order body:**
```json
{
  "ticker":      "AAPL",
  "action":      "BUY_CALL",
  "strike":      195.0,
  "expiry":      "2025-07-18",
  "contracts":   1,
  "limitPrice":  2.50,
  "orderEffect": "open"
}
```

Actions: `BUY_CALL`, `BUY_PUT`, `SELL_CALL`, `SELL_PUT`

---

## Strategy Logic

### 1. Momentum Breakout
- **Trigger:** Volume ≥ 1.5× 20-day average AND price at/above 20-day high
- **Trade:** Buy ATM call (breakout) or ATM put (breakdown)
- **High confidence:** Volume ≥ 2× + 5-day momentum > 3%

### 2. IV Crush / Earnings
- **Near earnings (≤7 days):** Buy ATM straddle to capture directional move
- **High IV without catalyst:** Sell OTM call to harvest premium decay
- **IV proxy:** Bollinger Band width > 8% = elevated, > 14% = extreme

### 3. Trend + Technicals
- **Bullish:** MACD crosses above signal + price > EMA20 + price > SMA50 + RSI 40–70
- **Bearish:** MACD crosses below + price < both MAs + RSI 30–60
- **RSI Bounce:** RSI < 32 while price holds above SMA50

---

## Risk Warnings

- **robin_stocks uses Robinhood's unofficial private API.** It may break without notice.
- All orders are **limit orders** (no market orders on options — spreads are too wide).
- This software does not constitute financial advice.
- **Always test with a paper account first.** Robinhood doesn't offer paper trading, so use a small position size for initial live testing.
- Options can expire worthless. Never risk more than you can afford to lose.

---

## File Structure

```
optflow-backend/
├── app.py                  # Flask entry point
├── requirements.txt
├── routes/
│   ├── auth.py             # Robinhood login/logout
│   ├── market.py           # Yahoo Finance quotes + history + technicals
│   ├── options.py          # Options chains, IV rank, near-money strikes
│   ├── orders.py           # Place / cancel / monitor RH orders
│   └── strategies.py       # Signal engine (momentum, IV crush, trend)
```
